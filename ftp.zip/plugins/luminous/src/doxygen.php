<?php
// A few things to make Doxygen a little nicer. No code here.

/**
 * @mainpage
 *
 * This is the API documentation for Luminous, a PHP syntax highlighter.
 * This is mostly for development purposes, and not a lot of use to users.
 *
 * However, users may be interested in the \link luminous user's API \endlink 
 *  and the  LuminousOptions class 
 *
 *
 * Luminous site: http://luminous.asgaard.co.uk
 * 
 * User's documentation:  http://luminous.asgaard.co.uk/index.php/docs/show/index
 *
 *
 */

